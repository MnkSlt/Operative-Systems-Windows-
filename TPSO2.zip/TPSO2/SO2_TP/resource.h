//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CONTROL.rc
//
#define IDI_ICON_CONTROL                101
#define IDC_CURSOR_CONTROL              102
#define IDR_MENU_CONTROL                103
#define ID_AEROPORTOS_CRIAR             40001
#define ID_AVI40002                     40002
#define ID_AVI40003                     40003
#define ID_AVIOES_SUSPENDER             40004
#define ID_AVIOES_ATIVAR                40005
#define ID_LISTAR                       40006
#define ID_TERMINAR                     40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
